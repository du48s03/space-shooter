Space Fighter
Version 1.0.0.0
Author: Angus Ding
Date:2016/02/19

Instructions:
Use arrow keys to change options in the menu
Use <Enter> to select

Player Controls:

Player1:
Accelerate:     W
Rotate Left:    A
Rotate Right:   D
Fire:           S
Switch Weapon:  Q

Player2:
Accelerate:     Y
Rotate Left:    G
Rotate Right:   J
Fire:           H
Switch Weapon:  T

Player3:
Accelerate:     9
Rotate Left:    I
Rotate Right:   P
Fire:           O
Switch Weapon:  8

Player4:
Accelerate:     up
Rotate Left:    left
Rotate Right:   right
Fire:           right shift
Switch Weapon:  down


Notes:
Customizable key binding will be available in the next version. 
